This is a minimal test project for DEFault `/api/analyze-project`.

Files:
- `adapter.py`: exposes `build_model()` and `load_data()`.
- `requirements.txt`: declares TensorFlow dependency for pre-check validation.

Zip this folder (or use the prebuilt zip in `examples/test_project_minimal.zip`) and upload in the web UI.
